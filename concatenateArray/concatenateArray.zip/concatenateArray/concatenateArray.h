#include <stdio.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#include <ctype.h>


void mergeArray(int len, unsigned char *message, char *a);

