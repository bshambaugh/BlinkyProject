#include <stdio.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#include <ctype.h>

void voidArray(int len, char a[]);
void mergeArray(int len, unsigned char *message, char *a);

